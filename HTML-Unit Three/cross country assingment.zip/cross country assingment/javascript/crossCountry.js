 function updateRefactored(button) {
     var displayName = '';
     var firstLapSeconds = 0;
     var secondLapSeconds = 0;
     var totalTimeSeconds = 0;
     var secondSplit = 0;
     var thirdSplit = 0;
     var selector = button;
     var displayName = '';
     var row = button.parentElement.parentElement;
     var rowData = row.children;
     //getting the information
     // td -> input -> value  --- children always returns an array
     var firstName = rowData[0].children[0].value;
     if (isEmpty(firstName)) {
         alert("please enter a first name.");
     }
     var lastName = rowData[1].children[0].value;
     if (isEmpty(lastName)) {
         alert("Please enter a last name");
     }
     var firstLap = rowData[2].children[0].value;
     if (isEmpty(firstLap)) {
         alert("Please enter a first lap.");
     }
     var secondLap = rowData[3].children[0].value;
     if (isEmpty(secondLap)) {
         alert("Please enter a second lap. ");
     }
     var totalTime = rowData[4].children[0].value;
     if (isEmpty(totalTime)) {
         alert("Please enter a total time.");
     }

     var firstTimeBreak = splitStuff(firstLap);
     var secondTimeBreak = splitStuff(secondLap);
     var totalTimeBreak = splitStuff(totalTime);
     //these hold the converted time
     var time = [];
     var time1 = [];
     var time2 = [];

     time = parseDecimals(firstTimeBreak);
     time1 = parseDecimals(secondTimeBreak);
     time2 = parseDecimals(totalTimeBreak);

     firstLapSeconds = toSeconds(time[0], time[1]);
     secondLapSeconds = toSeconds(time1[0], time1[1]);
     totalLapSeconds = toSeconds(time2[0], time2[1]);

     var secondSplitSeconds = secondLapSeconds - firstLapSeconds;
     var thirdSplitSeconds = totalLapSeconds - secondLapSeconds;
     secondSplit = timeConvert(secondSplitSeconds);
     thirdSplit = timeConvert(thirdSplitSeconds);
     displayName = firstName + " " + lastName;

     var rows = document.getElementById('inputTable');
     if (row == firstInputRow) {
         document.getElementById('NameOutPut1').value = displayName;
         document.getElementById('firstSplitOutput1').value = firstLap;
         document.getElementById('secondSplitOutput1').value = secondSplit.toString();
         document.getElementById('thirdSplitOutput1').value = thirdSplit.toString();
         document.getElementById('totalTimeOutput1').value = document.getElementById('totalTime1').value;
         save1[0] = displayName;
         save1[1] = firstLap;
         save1[2] = secondSplit.toString();
         save1[3] = thirdSplit.toString();
         save1[4] = document.getElementById('totalTime1').value;
     } else if (row == secondInputRow) {
         document.getElementById('NameOutPut2').value = displayName;
         document.getElementById('firstSplitOutput2').value = firstLap;
         document.getElementById('secondSplitOutput2').value = secondSplit.toString();
         document.getElementById('thirdSplitOutput2').value = thirdSplit.toString();
         document.getElementById('totalTimeOutput2').value = document.getElementById('totalTime2').value;
         save2[0] = displayName;
         save2[1] = firstLap;
         save2[2] = secondSplit.toString();
         save2[3] = thirdSplit.toString();
         save2[4] = document.getElementById('totalTime2').value;

     } else if (row == thirdInputRow) {
         document.getElementById('NameOutPut3').value = displayName;
         document.getElementById('firstSplitOutput3').value = firstLap;
         document.getElementById('secondSplitOutput3').value = secondSplit.toString();
         document.getElementById('thirdSplitOutput3').value = thirdSplit.toString();
         document.getElementById('totalTimeOutput3').value = document.getElementById('totalTime3').value;
         save3[0] = displayName;
         save3[1] = firstLap;
         save3[2] = secondSplit.toString();
         save3[3] = thirdSplit.toString();
         save3[4] = document.getElementById('totalTime3').value;
     } else if (row == fourthInputRow) {
         document.getElementById('NameOutPut4').value = displayName;
         document.getElementById('firstSplitOutput4').value = firstLap;
         document.getElementById('secondSplitOutput4').value = secondSplit.toString();
         document.getElementById('thirdSplitOutput4').value = thirdSplit.toString();
         document.getElementById('totalTimeOutput4').value = document.getElementById('totalTime4').value;
         save4[0] = displayName;
         save4[1] = firstLap;
         save4[2] = secondSplit.toString();
         save4[3] = thirdSplit.toString();
         save4[4] = document.getElementById('totalTime4').value;
     }
 }

 function clean(button) {
     var clean = " ";
     var row = button.parentElement.parentElement;
     var rowData = row.children;
     if (row == firstInputRow) {
         document.getElementById('NameOutPut1').value = clean;
         document.getElementById('firstSplitOutput1').value = clean;
         document.getElementById('secondSplitOutput1').value = clean;
         document.getElementById('thirdSplitOutput1').value = clean;
         document.getElementById('totalTimeOutput1').value = clean;
     } else if (row == secondInputRow) {
         document.getElementById('NameOutPut2').value = clean;
         document.getElementById('firstSplitOutput2').value = clean;
         document.getElementById('secondSplitOutput2').value = clean;
         document.getElementById('thirdSplitOutput2').value = clean;
         document.getElementById('totalTimeOutput2').value = clean;
     } else if (row == thirdInputRow) {
         document.getElementById('NameOutPut3').value = clean;
         document.getElementById('firstSplitOutput3').value = clean;
         document.getElementById('secondSplitOutput3').value = clean;
         document.getElementById('thirdSplitOutput3').value = clean;
         document.getElementById('totalTimeOutput3').value = clean;
     } else if (row == fourthInputRow) {
         document.getElementById('NameOutPut4').value = clean;
         document.getElementById('firstSplitOutput4').value = clean;
         document.getElementById('secondSplitOutput4').value = clean;
         document.getElementById('thirdSplitOutput4').value = clean;
         document.getElementById('totalTimeOutput4').value = clean;
     }


 }

 function restore(button) {
         var clean = " ";
         var row = button.parentElement.parentElement;
         var rowData = row.children;
         if (row == firstInputRow) {
             document.getElementById('NameOutPut1').value = save1[0];
             document.getElementById('firstSplitOutput1').value = save1[1];
             document.getElementById('secondSplitOutput1').value = save1[2];
             document.getElementById('thirdSplitOutput1').value = save1[3];
             document.getElementById('totalTimeOutput1').value = save1[4];
         } else if (row == secondInputRow) {
             document.getElementById('NameOutPut2').value = save2[0];
             document.getElementById('firstSplitOutput2').value = save2[1];
             document.getElementById('secondSplitOutput2').value = save2[2];
             document.getElementById('thirdSplitOutput2').value = save2[3];
             document.getElementById('totalTimeOutput2').value = save2[4];
         } else if (row == thirdInputRow) {
             document.getElementById('NameOutPut3').value = save3[0];
             document.getElementById('firstSplitOutput3').value = save3[1];
             document.getElementById('secondSplitOutput3').value = save3[2];
             document.getElementById('thirdSplitOutput3').value = save3[3];
             document.getElementById('totalTimeOutput3').value = save3[4];
         } else if (row == fourthInputRow) {
             document.getElementById('NameOutPut4').value = save4[0];
             document.getElementById('firstSplitOutput4').value = save4[1];
             document.getElementById('secondSplitOutput4').value = save4[2];
             document.getElementById('thirdSplitOutput4').value = save4[3];
             document.getElementById('totalTimeOutput4').value = save4[4];
         }
     }
     //method that converts everything to seconds and returns the total
 function toSeconds(a, b) {
     seconds = b
     min = a
     seconds += min * 60;
     totalLapSeconds = seconds;
     return seconds;
 }
 //returns if the string is empty or null
 function isEmpty(str) {
     return (!str || 0 === str.length);
 }
 //converting the seconds back into minutes:seconds
 function timeConvert(num) {
     if (!isNaN(num)) {
         return ((parseInt(num / 60)) + (":") + ((num % 60).toFixed(2)));
     } else {
         return " ";
     }
 }
//function splits the string on ":" for given times
 function splitStuff(str){
 	return str.split(":");
 }
 //function to parse things into decimals
 function parseDecimals(str){
 	var temp = [];
 	for (var i = 0; i < str.length; i++) {
         temp [i] = parseFloat(str[i]);
     }
     return temp;
 }

